import { showToast } from "./ui.js";

/**
 * A wrapper for making POST requests using jQuery's ajax method.
 * @param {string} url The URL to send the request to.
 * @param {object} data The data to send.
 * @returns {Promise} A jQuery promise.
 */
function post(url, data) {
  return $.ajax({
    url: url,
    type: "POST",
    data: data,
    dataType: "json",
  });
}

/**
 * A generic handler for forms that submit via AJAX.
 * @param {Event} e The form submission event.
 */
export function handleAjaxFormSubmit(e) {
  e.preventDefault();
  const form = $(e.currentTarget);
  const action = form.attr("action");
  const data = form.serialize();
  const submitBtn = form.find('button[type="submit"]');
  const originalBtnText = submitBtn.text();

  submitBtn.html(
    '<span class="spinner-border spinner-border-sm"></span> Loading...'
  );
  submitBtn.prop("disabled", true);

  post(action, data)
    .done(function (response) {
      if (response.success || response.status === "success") {
        showToast("success", response.message || "Success!");
        if (form.data("reload")) {
          location.reload();
        }
      } else {
        showToast("danger", response.message || "An error occurred.");
      }
    })
    .fail(function () {
      showToast("danger", "Request failed. Please try again.");
    })
    .always(function () {
      submitBtn.html(originalBtnText);
      submitBtn.prop("disabled", false);
    });
}

/**
 * Changes the status of a task.
 * @param {string} taskId The ID of the task.
 * @param {string} newStatus The new status.
 */
export function changeTaskStatus(taskId, newStatus) {
  post("controllers/task_controller.php", {
    action: "change_status",
    task_id: taskId,
    status: newStatus,
  })
    .done(function (response) {
      console.log("Response:", response);
      if (response.status === "success") {
        showToast("success", response.message || "Status updated!");
      } else {
        showToast("danger", response.message || "Update failed.");
      }
    })
    .fail(function () {
      showToast("danger", "Request failed.");
    });
}
