<?php
// Ensure Admin
if (!isAdmin()) {
  header('Location: ' . Config::getBaseUrl() . 'index.php?page=dashboard');
  exit;
}

require_once Config::ROOT_DIR . '/models/User.php';

$users = User::getAll();
?>

<h2>Manage Users</h2>

<!-- Create User Form -->
<div class="card mb-4">
  <div class="card-header">Create New User</div>
  <div class="card-body">
    <form method="POST" action="<?= Config::getBaseUrl() ?>controllers/user_controller.php">
      <input type="hidden" name="action" value="create">
      <div class="row">
        <div class="col-md-3 mb-3">
          <label for="name" class="form-label">Name</label>
          <input type="text" class="form-control" id="name" name="name" required>
        </div>
        <div class="col-md-3 mb-3">
          <label for="email" class="form-label">Email</label>
          <input type="email" class="form-control" id="email" name="email" required>
        </div>
        <div class="col-md-3 mb-3">
          <label for="level" class="form-label">Level</label>
          <select class="form-select" id="level" name="level" required>
            <option value="">Select</option>
            <?php foreach (Config::USER_LEVELS as $level): ?>
              <option value="<?= $level ?>"><?= $level ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="col-md-3 mb-3 form-check mt-4">
          <input type="checkbox" class="form-check-input" id="is_team_lead" name="is_team_lead">
          <label class="form-check-label" for="is_team_lead">Is Team Lead (for Seniors)</label>
        </div>
      </div>
      <button type="submit" class="btn btn-primary">Create</button>
    </form>
  </div>
</div>

<!-- Users Table -->
<table class="table table-striped">
  <thead>
    <tr>
      <th>ID</th>
      <th>Name</th>
      <th>Email</th>
      <th>Level</th>
      <th>Team Lead</th>
      <th>Approved</th>
      <th>Actions</th>
    </tr>
  </thead>
  <tbody>
    <?php foreach ($users as $user): ?>
      <tr>
        <td><?= $user['id'] ?></td>
        <td><?= htmlspecialchars($user['name']) ?></td>
        <td><?= htmlspecialchars($user['email']) ?></td>
        <td><?= htmlspecialchars($user['level']) ?></td>
        <td><?= $user['is_team_lead'] ? 'Yes' : 'No' ?></td>
        <td><?= $user['is_approved'] ? 'Yes' : 'No' ?></td>
        <td>
          <?php if (!$user['is_approved']): ?>
            <form method="POST" action="<?= Config::getBaseUrl() ?>controllers/user_controller.php" class="d-inline">
              <input type="hidden" name="action" value="approve">
              <input type="hidden" name="id" value="<?= $user['id'] ?>">
              <button type="submit" class="btn btn-sm btn-success">Approve</button>
            </form>
          <?php endif; ?>
          <!-- Edit Button triggers modal -->
          <button class="btn btn-sm btn-warning" data-bs-toggle="modal" data-bs-target="#editUserModal<?= $user['id'] ?>">Edit</button>
          <form method="POST" action="<?= Config::getBaseUrl() ?>controllers/user_controller.php" class="d-inline" onsubmit="return confirm('Are you sure you want to reset the password?');">
            <input type="hidden" name="action" value="reset_password">
            <input type="hidden" name="id" value="<?= $user['id'] ?>">
            <button type="submit" class="btn btn-sm btn-secondary">Reset Password</button>
          </form>
          <form method="POST" action="<?= Config::getBaseUrl() ?>controllers/user_controller.php" class="d-inline" onsubmit="return confirm('Delete user?');">
            <input type="hidden" name="action" value="delete">
            <input type="hidden" name="id" value="<?= $user['id'] ?>">
            <button type="submit" class="btn btn-sm btn-danger">Delete</button>
          </form>
        </td>
      </tr>

      <!-- Edit Modal per user -->
      <div class="modal fade" id="editUserModal<?= $user['id'] ?>" tabindex="-1" aria-labelledby="editUserLabel" aria-hidden="true">
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title">Edit User <?= htmlspecialchars($user['name']) ?></h5>
              <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
              <form method="POST" action="<?= Config::getBaseUrl() ?>controllers/user_controller.php">
                <input type="hidden" name="action" value="update">
                <input type="hidden" name="id" value="<?= $user['id'] ?>">
                <div class="mb-3">
                  <label for="name<?= $user['id'] ?>" class="form-label">Name</label>
                  <input type="text" class="form-control" id="name<?= $user['id'] ?>" name="name" value="<?= htmlspecialchars($user['name']) ?>" required>
                </div>
                <div class="mb-3">
                  <label for="email<?= $user['id'] ?>" class="form-label">Email</label>
                  <input type="email" class="form-control" id="email<?= $user['id'] ?>" name="email" value="<?= htmlspecialchars($user['email']) ?>" required>
                </div>
                <div class="mb-3">
                  <label for="level<?= $user['id'] ?>" class="form-label">Level</label>
                  <select class="form-select" id="level<?= $user['id'] ?>" name="level" required>
                    <?php foreach (Config::USER_LEVELS as $level): ?>
                      <option value="<?= $level ?>" <?= $user['level'] === $level ? 'selected' : '' ?>><?= $level ?></option>
                    <?php endforeach; ?>
                  </select>
                </div>
                <div class="form-check mb-3">
                  <input type="checkbox" class="form-check-input" id="is_team_lead<?= $user['id'] ?>" name="is_team_lead" <?= $user['is_team_lead'] ? 'checked' : '' ?>>
                  <label class="form-check-label" for="is_team_lead<?= $user['id'] ?>">Is Team Lead</label>
                </div>
                <button type="submit" class="btn btn-primary">Update</button>
              </form>
            </div>
          </div>
        </div>
      </div>
    <?php endforeach; ?>
  <script>
  document.addEventListener('DOMContentLoaded', function() {
    // For create form
    const createLevel = document.getElementById('level');
    const createIsTeamLead = document.getElementById('is_team_lead');

    function toggleCreateTeamLead() {
      if (createLevel.value !== 'Senior') {
        createIsTeamLead.disabled = true;
        createIsTeamLead.checked = false;
      } else {
        createIsTeamLead.disabled = false;
      }
    }
    createLevel.addEventListener('change', toggleCreateTeamLead);
    toggleCreateTeamLead();

    // For edit modals
    <?php foreach ($users as $user): ?>
      const editLevel_<?= $user['id'] ?> = document.getElementById('level<?= $user['id'] ?>');
      const editIsTeamLead_<?= $user['id'] ?> = document.getElementById('is_team_lead<?= $user['id'] ?>');

      function toggleEditTeamLead_<?= $user['id'] ?>() {
        if (editLevel_<?= $user['id'] ?>.value !== 'Senior') {
          editIsTeamLead_<?= $user['id'] ?>.disabled = true;
          editIsTeamLead_<?= $user['id'] ?>.checked = false;
        } else {
          editIsTeamLead_<?= $user['id'] ?>.disabled = false;
        }
      }
      editLevel_<?= $user['id'] ?>.addEventListener('change', toggleEditTeamLead_<?= $user['id'] ?>);
      toggleEditTeamLead_<?= $user['id'] ?>();
    <?php endforeach; ?>
  });
</script>