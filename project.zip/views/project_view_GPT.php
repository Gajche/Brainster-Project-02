<?php
// Ensure logged in
if (!isLoggedIn()) {
  header('Location: ' . Config::getBaseUrl() . 'index.php?page=login');
  exit;
}

require_once Config::ROOT_DIR . '/models/Project.php';
require_once Config::ROOT_DIR . '/models/Task.php';
require_once Config::ROOT_DIR . '/models/User.php';

$projectId = $_GET['id'] ?? 0;
$project = Project::getById($projectId);
$userId = $_SESSION['user_id'];
$userLevel = $_SESSION['user_level'] ?? null; // Get user level from session
$isTeamLead = $project && $project->canManageTeam($userId);

if (!$project || !$project->canAccess($userId)) {
  $_SESSION[Config::FLASH_ERROR] = 'Project not found or access denied.';
  header('Location: ' . Config::getBaseUrl() . 'index.php?page=dashboard');
  exit;
}

$team = User::getProjectTeam($projectId);
// All users for add member dropdown (exclude current team)
$allUsers = User::getAll();
$availableMembers = array_filter($allUsers, function ($u) use ($team) {
  return !in_array($u['id'], array_column($team, 'id')) && $u['level'] !== 'Admin';
});

$tasks = Task::getByProject($projectId);

// Group tasks by status for Kanban view
$tasksByStatus = [];
foreach (Config::TASK_STATUSES as $status) {
  $tasksByStatus[$status] = [];
}
foreach ($tasks as $task) {
  $tasksByStatus[$task->getStatus()][] = $task;
}
?>

<h2><?= htmlspecialchars($project->getTitle()) ?></h2>

<div class="card mb-4">
  <div class="card-header">Project Details</div>
  <div class="card-body">
    <p><strong>Description:</strong> <?= htmlspecialchars($project->getDescription() ?: 'N/A') ?></p>
    <p><strong>Requirements:</strong> <?= htmlspecialchars($project->getRequirements() ?: 'N/A') ?></p>
    <p><strong>Estimated Time:</strong> <?= htmlspecialchars($project->getEstimatedTime() ?: 'N/A') ?></p>
    <p><strong>Deadline:</strong> <?= htmlspecialchars($project->getDeadline() ?: 'N/A') ?></p>
    <p><strong>Status:</strong> <?= htmlspecialchars($project->getStatus()) ?></p>
    <?php if ($isTeamLead && $project->getStatus() === 'Active'): ?>
      <form method="POST" action="<?= Config::getBaseUrl() ?>controllers/project_controller.php">
        <input type="hidden" name="action" value="mark_done">
        <input type="hidden" name="id" value="<?= $projectId ?>">
        <button type="submit" class="btn btn-success">Mark as Done</button>
      </form>
    <?php endif; ?>
  </div>
</div>

<h3>Team Members</h3>
<table class="table table-striped mb-4">
  <thead>
    <tr>
      <th>Name</th>
      <th>Level</th>
      <?php if ($isTeamLead): ?>
        <th>Actions</th>
      <?php endif; ?>
    </tr>
  </thead>
  <tbody>
    <?php foreach ($team as $member): ?>
      <tr>
        <td><?= htmlspecialchars($member['name']) ?></td>
        <td><?= htmlspecialchars($member['level']) ?></td>
        <?php if ($isTeamLead): ?>
          <td>
            <?php if ($member['id'] != $project->getTeamLeadId()): ?>
              <form method="POST" action="<?= Config::getBaseUrl() ?>controllers/project_controller.php" class="d-inline">
                <input type="hidden" name="action" value="remove_member">
                <input type="hidden" name="project_id" value="<?= $projectId ?>">
                <input type="hidden" name="member_id" value="<?= $member['id'] ?>">
                <button type="submit" class="btn btn-sm btn-danger">Remove</button>
              </form>
            <?php endif; ?>
          </td>
        <?php endif; ?>
      </tr>
    <?php endforeach; ?>
  </tbody>
</table>

<?php if ($isTeamLead): ?>
  <!-- Add Member Form -->
  <div class="card mb-4">
    <div class="card-header">Add Team Member</div>
    <div class="card-body">
      <form method="POST" action="<?= Config::getBaseUrl() ?>controllers/project_controller.php">
        <input type="hidden" name="action" value="add_member">
        <input type="hidden" name="project_id" value="<?= $projectId ?>">
        <div class="mb-3">
          <label for="member_id" class="form-label">Select User</label>
          <select class="form-select" id="member_id" name="member_id" required>
            <option value="">Choose...</option>
            <?php foreach ($availableMembers as $user): ?>
              <option value="<?= $user['id'] ?>"><?= htmlspecialchars($user['name']) ?> (<?= $user['level'] ?>)</option>
            <?php endforeach; ?>
          </select>
        </div>
        <button type="submit" class="btn btn-primary">Add</button>
      </form>
    </div>
  </div>
<?php endif; ?>

<h3>Tasks</h3>

<?php if (User::getById($userId)->canCreateTask($projectId)): ?>
  <!-- Create Task Form -->
  <div class="card mb-4">
    <div class="card-header">Create New Task</div>
    <div class="card-body">
      <form method="POST" action="<?= Config::getBaseUrl() ?>controllers/task_controller.php">
        <input type="hidden" name="action" value="create">
        <input type="hidden" name="project_id" value="<?= $projectId ?>">
        <div class="mb-3">
          <label for="title" class="form-label">Title</label>
          <input type="text" class="form-control" id="title" name="title" required>
        </div>
        <div class="mb-3">
          <label for="description" class="form-label">Description</label>
          <textarea class="form-control" id="description" name="description" rows="3"></textarea>
        </div>
        <button type="submit" class="btn btn-primary">Create Task</button>
      </form>
    </div>
  </div>
<?php endif; ?>

<div class="kanban-container">
  <?php foreach (Config::TASK_STATUSES as $status): ?>
    <div class="kanban-column" data-status="<?= htmlspecialchars($status) ?>">
      <div class="kanban-column-header"><?= htmlspecialchars($status) ?></div>
      <div class="kanban-cards">
        <?php foreach ($tasksByStatus[$status] as $task): ?>
          <?php
          $assigned = User::getById($task->getAssignedTo());
          $assignedName = $assigned ? htmlspecialchars($assigned->getName()) : 'Unassigned';
          $canEditDelete = $userLevel === 'Admin' || ($userLevel === 'Senior' && User::isInProject($userId, $projectId));
          ?>
          <div class="kanban-card" data-task-id="<?= $task->getId() ?>">
            <div class="kanban-card-title"><?= htmlspecialchars($task->getTitle()) ?></div>
            <div class="kanban-card-meta">
              <small>Assigned: <?= $assignedName ?></small><br>
              <small>Created: <?= htmlspecialchars($task->getCreatedAt()) ?></small>
            </div>
            <div class="kanban-card-actions mt-2">
              <button class="btn btn-sm btn-info view-task-btn" data-task-id="<?= $task->getId() ?>">View</button>
              <?php if ($canEditDelete): ?>
                <button class="btn btn-sm btn-warning" data-bs-toggle="modal" data-bs-target="#editTaskModal<?= $task->getId() ?>">Edit</button>
                <button class="btn btn-sm btn-danger delete-task-btn" data-task-id="<?= $task->getId() ?>">Delete</button>
              <?php endif; ?>
            </div>
          </div>
        <?php endforeach; ?>
      </div>
    </div>
  <?php endforeach; ?>
</div>

<!-- Task Edit Modals (unique per task) -->
<?php foreach ($tasks as $task): ?>
  <?php
  $canEditDelete = $userLevel === 'Admin' || ($userLevel === 'Senior' && User::isInProject($userId, $projectId));
  if ($canEditDelete):
  ?>
    <div class="modal fade" id="editTaskModal<?= $task->getId() ?>" tabindex="-1" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title">Edit Task: <?= htmlspecialchars($task->getTitle()) ?></h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <div class="modal-body">
            <form class="ajax-form" data-reload="#kanban-container" method="POST" action="<?= Config::getBaseUrl() ?>controllers/task_controller.php">
              <input type="hidden" name="action" value="update">
              <input type="hidden" name="task_id" value="<?= $task->getId() ?>">
              <div class="mb-3">
                <label for="title<?= $task->getId() ?>" class="form-label">Title</label>
                <input type="text" class="form-control" id="title<?= $task->getId() ?>" name="title" value="<?= htmlspecialchars($task->getTitle()) ?>" required>
              </div>
              <div class="mb-3">
                <label for="description<?= $task->getId() ?>" class="form-label">Description</label>
                <textarea class="form-control" id="description<?= $task->getId() ?>" name="description" rows="3"><?= htmlspecialchars($task->getDescription()) ?></textarea>
              </div>
              <button type="submit" class="btn btn-primary">Update</button>
            </form>
          </div>
        </div>
      </div>
    </div>
  <?php endif; ?>
<?php endforeach; ?>